import 'package:flutter/material.dart';
import 'package:flutter_app_name/widget/search_bar.dart';

class Search extends StatefulWidget{
  @override
  _SearchState createState()=>_SearchState();

}

class _SearchState extends State<Search>{

  final PageController pageController=PageController(initialPage: 0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Column(
        children: [
          SearchBar(
            hideLeftBtn: true,
             hint: '请输入搜索内容' ,
            defalutTex: '',
              rightBtnClick:(){

              },
              speakBtnClick:(){

              },
              changed:_changeText
          ),
          Expanded(flex: 1, child: Text('搜索'))
        ],

      ),
    );
  }


  void _changeText(String value) {

  }
}